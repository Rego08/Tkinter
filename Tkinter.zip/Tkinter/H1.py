import tkinter as tk

aken = tk.Tk()

aken.title("Mario ülessanded")

aken.resizable(True, False)

aken.geometry("400x400")

aken.mainloop()