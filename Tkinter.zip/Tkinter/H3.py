import tkinter as tk
def main():
    aken = tk.Tk()
    aken.geometry("200x300")
    aken.title("Laenukalkulaator")
    # Funktsioon, mis kuvab sisestused
    viga = tk.Label(aken, text="Midagi läks valesti, proovi uuesti!", fg="red")
    vastus = tk.Label(aken, text="")
    def kuva_sisestus():
        try:
            laenusumma = sisestus1.get()
            aastaneintressimaar = sisestus2.get()
            laenuperiood = sisestus3.get()
            maksetearv = int(laenuperiood) * 12
            kuuintressimaar = float(aastaneintressimaar) / 100 / 12
            igakuinemakse = float(laenusumma) * (kuuintressimaar * (1 + kuuintressimaar) ** maksetearv) / ((1 + kuuintressimaar) ** maksetearv - 1)
            vahe = tk.Label(aken, text="", pady=10)
            vahe.pack()
            vastus.config(text=f"Igakuine makse: €{round(igakuinemakse,2)}", fg="black")
            vastus.pack()
        except:
            vastus.config(text="Midagi läks valesti, proovi uuesti!", fg="red")
            vastus.pack()

    # Esimene sisestusväli
    laenusummatxt = tk.Label(aken, text="Laenusumma (€):", pady=10)
    laenusummatxt.pack()
    sisestus1 = tk.Entry(aken)
    sisestus1.pack()
   
    # Teine sisestusväli
    aastaneintressimaartxt = tk.Label(aken, text="Aastane intressimäär (%):", pady=10)
    aastaneintressimaartxt.pack()
    sisestus2 = tk.Entry(aken)
    sisestus2.pack()

    laenuperioodtxt = tk.Label(aken, text="Laenuperiood (aastates):", pady=10)
    laenuperioodtxt.pack()
    sisestus3 = tk.Entry(aken)
    sisestus3.pack()
   
    # Nupp, mis käivitab funktsiooni kuva_sisestus
    vahe = tk.Label(aken, text="")
    vahe.pack()
    pilt = tk.PhotoImage(file="pilt.png")
    nupp = tk.Button(aken, text="Arvuta", command=kuva_sisestus, image=pilt, compound="left")
    nupp.pack()

    aken.mainloop()

if __name__ == "__main__":
    main()